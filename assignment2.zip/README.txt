README
to run client, use command ./chat379 localhost 2222 name1

to run server, use command ./server379 2222



type in /users to see all users connected to server currently

type in /updates to see all user-updates in the client

type in any message without '/' in the beginning to send a message
